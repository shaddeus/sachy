/*  figurky.h */

#ifndef FIGURKY_H
#define FIGURKY_H

#include "dat_struct.h"
#include <iostream>
#include <ncurses.h>

// Nastaveni vnitrni reprezentace oznaceni figurek. Implicitne se budou z integeru konvertovat na char
enum FIGURKY {
  PESAK = 1,
  STRELEC = 2,
  VEZ = 3,
  KUN = 4,
  DAMA = 5,
  KRAL = 6
};

enum BARVA {
  BILA = true,
  CERNA = false
};

// Kontejnerova trida pro jednotlive typy figurek - pesak, jezdec, vez, ...
class CFigurka {
  public:
                   CFigurka              ( void );
                   CFigurka              ( pozice_t, bool );
    virtual       ~CFigurka              ( void );
    virtual bool   tahni                 ( const tah_t & , bool );
    virtual void   vrat                  ( const tah_t & );
    virtual bool   mozneTahy             ( tah_t * &, bool ); // bohuzel se tam pouzivaji tahni a vrat a ty nejsou const
    int            getKolikratTazeno     ( void ) const { return ( kolikratTazeno ); }
    char           getTypFigurky         ( void ) const { return ( typFigurky ); }
    bool           getBarva              ( void ) const { return ( barva ); }
    pozice_t       getPozice             ( void ) const { return ( pozice ); }
    void           setPozice             ( const pozice_t& p ) { pozice = p; }
    virtual bool   getEnPassant          ( void ) const;
    friend         std::ostream & operator<<  ( std::ostream&, const CFigurka& );
    void           vykresli              ( const int ) const; 
    CFigurka      *sebranaFigurka;
    int            pReference;          // pocitana reference na objekt 
    void           vyreseniReferenciSebranaFigurka ( void );
  protected:
    char           typFigurky;         // viz. enum FIGURKY
    bool           barva;              // false -> cerna   ;   true -> bila
    pozice_t       pozice;
    int            kolikratTazeno; 
    bool           kralPoTahuNebudeNapaden    ( const pozice_t& );
    bool           overeniPlatnostiTahu  ( const tah_t& );
    bool           dostavamSach          ( void ) const;
    bool           pujdeTahnoutNaPolicko ( const pozice_t &, tah_t * &, int &, bool );
};

// Sahova figurka pesak
class CPesak : public CFigurka {
  public:
                   CPesak                ( pozice_t , bool );
                  ~CPesak                ( void );
    bool           tahni                 ( const tah_t & , bool);
    void           vrat                  ( const tah_t & );
    bool           mozneTahy             ( tah_t * &, bool );
    bool           getEnPassant          ( void ) const { return ( enPassant ); }
    friend         std::ostream & operator<<  ( std::ostream&, const CPesak& );
  protected:
    //void           zmenFigurku ( char novyTypFigurky );
    bool           enPassant;            // pokud true pesce je mozne brat mimochodem - en passant 
    pozice_t       sebranaFigurkaPozice; // kvuli vraceni tahu brani mimochodem - e.p.
};

// Sahova figurka DAMA
class CDama : public CFigurka {
  public:
                   CDama                 ( pozice_t , bool );
                  ~CDama                 ( void );
    bool           mozneTahy             ( tah_t * &, bool );
};

// Sahova figurka STRELEC
class CStrelec : public CFigurka {
  public:
                   CStrelec              ( pozice_t , bool );
                  ~CStrelec              ( void );
    bool           mozneTahy             ( tah_t * &, bool );
};


// Sahova figurka VEZ
class CVez : public CFigurka {
  public:
                   CVez                  ( pozice_t , bool );
                  ~CVez                  ( void );
    bool           mozneTahy             ( tah_t * &, bool );
};


// Sahova figurka KUN
class CKun : public CFigurka {
  public:
                   CKun                ( pozice_t , bool );
                  ~CKun                ( void );
    bool           mozneTahy           ( tah_t * &, bool );
};


// Sahova figurka KRAL
class CKral : public CFigurka {
  public:
                   CKral               ( pozice_t , bool );
                  ~CKral               ( void );
    bool           mozneTahy           ( tah_t * &, bool );
    bool           tahni               ( const tah_t & , bool );
    void           vrat                ( const tah_t & );
};

// jo, tohle asi neni moc pekne
#include "sach_global.h"
#include "chess.h"

#endif // FIGURKY_H

